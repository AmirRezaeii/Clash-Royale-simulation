package Model;

public interface Card {
    public int price();

    public String name();

    public User owner();
}
