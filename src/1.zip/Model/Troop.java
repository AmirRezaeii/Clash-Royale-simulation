package Model;
interface Troop{
    public int power();
    public int hitPoint();
}
