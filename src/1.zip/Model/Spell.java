package Model;

interface Spell{
    public int power();
}
